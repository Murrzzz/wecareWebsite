-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 13, 2022 at 01:59 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.3.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wecare_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_acc`
--

CREATE TABLE `admin_acc` (
  `i_id` int(11) NOT NULL,
  `v_username` varchar(75) NOT NULL,
  `v_password` varchar(75) NOT NULL,
  `d_date_created` date NOT NULL,
  `d_time_login` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_acc`
--

INSERT INTO `admin_acc` (`i_id`, `v_username`, `v_password`, `d_date_created`, `d_time_login`) VALUES
(1, 'roger', 'roger', '2021-10-04', 1633340275),
(2, 'user', 'user', '2021-10-04', 11),
(3, 'jamess', 'NHtYnJn7', '2021-10-04', 12);

-- --------------------------------------------------------

--
-- Table structure for table `admin_time`
--

CREATE TABLE `admin_time` (
  `i_id` int(9) NOT NULL,
  `i_start_time` varchar(75) NOT NULL,
  `i_end_time` varchar(75) NOT NULL,
  `i_day` varchar(75) NOT NULL,
  `i_time_dis` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_time`
--

INSERT INTO `admin_time` (`i_id`, `i_start_time`, `i_end_time`, `i_day`, `i_time_dis`) VALUES
(4, '', '', 'Monday', ' Monday:-'),
(5, '3:00Pm', '4:00Pm', 'Tuesday', ' Tuesday:3:00Pm-4:00Pm');

-- --------------------------------------------------------

--
-- Table structure for table `category_admin`
--

CREATE TABLE `category_admin` (
  `i_id` int(11) NOT NULL,
  `v_category_name` varchar(75) NOT NULL,
  `v_category_details` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category_admin`
--

INSERT INTO `category_admin` (`i_id`, `v_category_name`, `v_category_details`) VALUES
(5, '', ''),
(6, 'Email', 'using Gmail'),
(7, 'Meet_up', 'Locate the Location in the Message');

-- --------------------------------------------------------

--
-- Table structure for table `channel_admin`
--

CREATE TABLE `channel_admin` (
  `i_id` int(11) NOT NULL,
  `v_channel_name` varchar(75) NOT NULL,
  `v_channel_details` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `channel_admin`
--

INSERT INTO `channel_admin` (`i_id`, `v_channel_name`, `v_channel_details`) VALUES
(3, '', ''),
(4, 'Face_to_Face', 'Please Locate the the place in the Message area');

-- --------------------------------------------------------

--
-- Table structure for table `request`
--

CREATE TABLE `request` (
  `i_id` int(11) NOT NULL,
  `v_username` varchar(75) NOT NULL,
  `v_category_name` varchar(75) NOT NULL,
  `v_channel_name` varchar(50) NOT NULL,
  `time` varchar(100) NOT NULL,
  `v_message` varchar(500) NOT NULL,
  `status` varchar(70) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `request`
--

INSERT INTO `request` (`i_id`, `v_username`, `v_category_name`, `v_channel_name`, `time`, `v_message`, `status`) VALUES
(24, 'admin', '\"Email\"', '\"Face_to_Face\"', ' Tuesday:3:00Pm-4:00Pm', 'Bagong Silang Caloocan city', 'rejected'),
(25, 'Moore', '\"Email\"', '\"Face_to_Face\"', ' Tuesday:3:00Pm-4:00Pm', 'Bagong Silang Caloocan City', 'Process');

-- --------------------------------------------------------

--
-- Table structure for table `user_acc`
--

CREATE TABLE `user_acc` (
  `i_id` int(11) NOT NULL,
  `v_fullname` varchar(75) NOT NULL,
  `v_username` varchar(75) NOT NULL,
  `v_password` varchar(75) NOT NULL,
  `d_date_created` date NOT NULL,
  `d_time_login` time NOT NULL,
  `v_email` varchar(75) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_acc`
--

INSERT INTO `user_acc` (`i_id`, `v_fullname`, `v_username`, `v_password`, `d_date_created`, `d_time_login`, `v_email`) VALUES
(1, 'Roger', 'Murrzzz', 'LntGig==', '2021-10-07', '01:38:05', 'roger_sangol@yahoo.com'),
(2, 'roger', 'admin', 'P35YkIQ=', '2021-10-07', '04:54:44', 'roger'),
(3, '', 'roger', 'LHVSnJg=', '2022-01-06', '18:45:28', ''),
(4, '', 'roger', 'LHVSnJg=', '2022-01-06', '18:45:33', ''),
(5, '', 'Moore', 'E3Vai48=', '2022-01-12', '23:22:35', ''),
(6, '', 'aa', 'P3s=', '2022-01-12', '23:40:30', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_acc`
--
ALTER TABLE `admin_acc`
  ADD PRIMARY KEY (`i_id`);

--
-- Indexes for table `admin_time`
--
ALTER TABLE `admin_time`
  ADD PRIMARY KEY (`i_id`);

--
-- Indexes for table `category_admin`
--
ALTER TABLE `category_admin`
  ADD PRIMARY KEY (`i_id`);

--
-- Indexes for table `channel_admin`
--
ALTER TABLE `channel_admin`
  ADD PRIMARY KEY (`i_id`);

--
-- Indexes for table `request`
--
ALTER TABLE `request`
  ADD PRIMARY KEY (`i_id`);

--
-- Indexes for table `user_acc`
--
ALTER TABLE `user_acc`
  ADD PRIMARY KEY (`i_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_acc`
--
ALTER TABLE `admin_acc`
  MODIFY `i_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `admin_time`
--
ALTER TABLE `admin_time`
  MODIFY `i_id` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `category_admin`
--
ALTER TABLE `category_admin`
  MODIFY `i_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `channel_admin`
--
ALTER TABLE `channel_admin`
  MODIFY `i_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `request`
--
ALTER TABLE `request`
  MODIFY `i_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `user_acc`
--
ALTER TABLE `user_acc`
  MODIFY `i_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
